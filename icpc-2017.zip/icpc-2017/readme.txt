This supplementary packapage contains extra information and results not included in the paper.

The repositories in our dataset we collected can be found in 'repos/repos.txt'.

The results are organized based on research questions.

RQ1: How redundant is source code?

Results for RQ1 are in the folder "rq1".
"noab.pdf" presents the redundancy rate of source code for sequences having different lengths when no abstraction is applied.
"lex.pdf" presents the redundancy rate of source code for sequences having different lengths when "token type only" is applied.

RQ2: To what extent are different code constructs redundant?

Results for RQ2 are in the folder "rq2".
"noab.pdf" presents the redundancy rate for different types of code construct when no abstraction is applied
"lex.pdf" presents the redundancy rate for different types of code construct when "token type only" is applied.
In the "compare" folder, results when different abstractions and sequence lengths are applied can be found. The file names are formatted as "[abstraction type]-n[sequence length].pdf". For example, to check the redundancy rates for different types of code construct when "token type only" is applied and the sequence length is 9, check the file "lex-n9.pdf".

The raw results of the 30-system case study can be found in the folder "rq2/case".

RQ3: How effective is the language model in supporting code completion?

Results for RQ3 are in the folder "rq3". The graphs present the distribution of prediction accuracy rates of the language model when supporting code completion (top n recommendations). The file names are formatted as "c[number of recommendations]". For example, if you want to check the distribution of prediction accuracy rates of the language model when supporting code completion (top 3 recommendations), access the file "c9.pdf".

RQ4: How effective is the language model in supporting code completion for different types of code constructs?

Results for RQ4 are in the folder "rq4". The graphs present the distribution of prediction accuracy rates of the language model when supporting code completion on different types of code constructs (top n recommendations). The file names are formatted as "c[number of recommendations]". For example, if you want to check the distribution of prediction accuracy rates of the language model when supporting code completion on different types of code constructs (top 3 recommendations), access the file "c3.pdf".
In the "compare" folder, results when different n and different number of recommendations are applied can be found. The file names are formatted as "n[n]-c[number of recommendations].pdf". For example, to check the prediction accuracy rates of the tri-gram language model when supporting code completion on different types of code constructs (top 3 recommendations), check the file "n3-c3.pdf".

The raw results of the 30-system case study can be found in the folder "rq4/case".